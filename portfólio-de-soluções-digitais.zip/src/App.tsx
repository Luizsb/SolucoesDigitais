/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  Moon, 
  Sun,
  Bell, 
  Plus, 
  Grid, 
  List as ListIcon, 
  ChevronDown, 
  User, 
  BrainCircuit, 
  FolderKanban, 
  BarChart3, 
  Workflow, 
  TrendingUp, 
  Zap, 
  ArrowRight,
  Share2,
  Network,
  ExternalLink,
  X,
  Info,
  CheckCircle2,
  Clock,
  Target,
  Pencil,
  Trash2
} from "lucide-react";

// --- Types ---

type Status = 'Em uso' | 'Piloto' | 'Em desenvolvimento';
type ViewMode = 'grid' | 'list';
type Theme = 'light' | 'dark';
type Tab = 'dashboard' | 'solutions' | 'admin';

interface Solution {
  id: string;
  title: string;
  category: string;
  status: Status;
  responsible: string;
  impact: string;
  description: string;
  features: string[];
  imageUrl: string;
  hasDemo: boolean;
  icon: React.ReactNode;
  iconBg: string;
  iconColor: string;
}

// --- Mock Data ---

const SOLUTIONS: Solution[] = [
  {
    id: '1',
    title: 'Brieflab',
    category: 'IA & Estratégia',
    status: 'Em uso',
    responsible: 'Ana Martins',
    impact: 'Redução de 40% no tempo de criação de briefings técnicos através de LLMs personalizados.',
    description: 'O Brieflab é uma plataforma inteligente que utiliza modelos de linguagem de última geração para transformar ideias brutas em briefings técnicos estruturados. Ele analisa o contexto do projeto, identifica requisitos ocultos e sugere as melhores abordagens tecnológicas.',
    features: [
      'Geração automática de User Stories',
      'Análise de viabilidade técnica preliminar',
      'Exportação direta para Jira e Azure DevOps',
      'Customização de tom de voz e complexidade'
    ],
    imageUrl: 'https://picsum.photos/seed/brieflab/800/450',
    hasDemo: true,
    icon: <BrainCircuit size={24} />,
    iconBg: 'bg-primary/10',
    iconColor: 'text-primary'
  },
  {
    id: '2',
    title: 'Acervo Digital',
    category: 'Gestão de Ativos',
    status: 'Piloto',
    responsible: 'Carlos Eduardo',
    impact: 'Centralização de documentos históricos com indexação automática via OCR avançado.',
    description: 'Uma solução robusta para a preservação da memória institucional. O Acervo Digital digitaliza, cataloga e torna pesquisável décadas de documentos, fotos e registros, utilizando visão computacional para extrair metadados automaticamente.',
    features: [
      'OCR multi-idioma de alta precisão',
      'Busca semântica em todo o acervo',
      'Controle de acesso granular por departamento',
      'Preservação digital em formatos de longo prazo'
    ],
    imageUrl: 'https://picsum.photos/seed/acervo/800/450',
    hasDemo: false,
    icon: <FolderKanban size={24} />,
    iconBg: 'bg-tertiary/10',
    iconColor: 'text-tertiary'
  },
  {
    id: '3',
    title: 'Dash Qualidade Revisão',
    category: 'Analytics',
    status: 'Em desenvolvimento',
    responsible: 'Juliana Luz',
    impact: 'Monitoramento em tempo real de KPIs de erro e produtividade do time de revisão.',
    description: 'Este dashboard fornece uma visão 360º sobre o processo de revisão de conteúdo. Ele identifica gargalos operacionais, padrões de erros recorrentes e ajuda na alocação eficiente de recursos baseada em dados reais.',
    features: [
      'Atualização de dados em tempo real',
      'Alertas automáticos de desvio de KPI',
      'Mapas de calor de erros por categoria',
      'Relatórios customizáveis para stakeholders'
    ],
    imageUrl: 'https://picsum.photos/seed/dash/800/450',
    hasDemo: true,
    icon: <BarChart3 size={24} />,
    iconBg: 'bg-secondary/10',
    iconColor: 'text-secondary'
  },
  {
    id: '4',
    title: 'Divisor Automático PDFs',
    category: 'Automação',
    status: 'Em uso',
    responsible: 'Marcos Silva',
    impact: 'Fragmentação inteligente de arquivos volumosos baseada em conteúdo semântico.',
    description: 'Ferramenta utilitária que resolve o problema de processar grandes volumes de documentos PDF. Ela não apenas divide o arquivo, mas entende onde cada seção começa e termina, mantendo a integridade lógica do documento.',
    features: [
      'Divisão baseada em palavras-chave',
      'Renomeação automática de arquivos de saída',
      'Processamento em lote (batch processing)',
      'Integração via API para fluxos externos'
    ],
    imageUrl: 'https://picsum.photos/seed/pdf/800/450',
    hasDemo: false,
    icon: <Workflow size={24} />,
    iconBg: 'bg-on-surface/5',
    iconColor: 'text-on-surface'
  },
  {
    id: '5',
    title: 'Genius Support',
    category: 'Atendimento',
    status: 'Em uso',
    responsible: 'Ricardo Lima',
    impact: 'Automação de 60% dos tickets de suporte nível 1 com IA generativa.',
    description: 'O Genius Support é um assistente inteligente que resolve dúvidas frequentes de alunos e professores em segundos, utilizando a base de conhecimento da empresa.',
    features: [
      'Integração com WhatsApp e Slack',
      'Escalonamento automático para humanos',
      'Análise de sentimento do usuário',
      'Dashboard de satisfação (CSAT)'
    ],
    imageUrl: 'https://picsum.photos/seed/genius/800/450',
    hasDemo: true,
    icon: <BrainCircuit size={24} />,
    iconBg: 'bg-primary/10',
    iconColor: 'text-primary'
  },
  {
    id: '6',
    title: 'Automação Contratual',
    category: 'Jurídico',
    status: 'Piloto',
    responsible: 'Beatriz Costa',
    impact: 'Geração de contratos complexos em menos de 2 minutos com validação jurídica.',
    description: 'Agilize o processo de contratação com nossa ferramenta de automação. Ela preenche cláusulas dinâmicas baseadas em dados de entrada e garante conformidade com as normas vigentes.',
    features: [
      'Templates dinâmicos',
      'Assinatura digital integrada',
      'Fluxo de aprovação multinível',
      'Repositório seguro em nuvem'
    ],
    imageUrl: 'https://picsum.photos/seed/contract/800/450',
    hasDemo: false,
    icon: <Workflow size={24} />,
    iconBg: 'bg-tertiary/10',
    iconColor: 'text-tertiary'
  }
];

// --- Components ---

const TopNavBar = ({ 
  theme, 
  toggleTheme, 
  searchQuery, 
  setSearchQuery,
  activeTab,
  setActiveTab
}: { 
  theme: Theme, 
  toggleTheme: () => void,
  searchQuery: string,
  setSearchQuery: (val: string) => void,
  activeTab: Tab,
  setActiveTab: (tab: Tab) => void
}) => (
  <nav className="fixed top-0 w-full z-50 glass-nav border-b border-outline-variant/15 shadow-2xl shadow-black/20">
    <div className="flex justify-between items-center w-full px-8 py-4 mx-auto max-w-[1600px]">
      <div className="flex items-center gap-8">
        <span className="text-xl font-bold tracking-tight text-on-surface">Portfólio de Soluções Digitais</span>
        <div className="hidden md:flex items-center gap-6">
          {[
            { id: 'dashboard', label: 'Dashboard' },
            { id: 'solutions', label: 'Soluções' },
            { id: 'admin', label: 'Admin' }
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as Tab)}
              className={`font-semibold transition-all relative py-1 ${
                activeTab === tab.id 
                  ? 'text-primary' 
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              {tab.label}
              {activeTab === tab.id && (
                <motion.div 
                  layoutId="activeTab"
                  className="absolute -bottom-1 left-0 right-0 h-0.5 bg-primary rounded-full"
                />
              )}
            </button>
          ))}
        </div>
      </div>
      
      <div className="flex items-center gap-6">
        <div className="relative group hidden lg:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant" size={16} />
          <input 
            type="text" 
            placeholder="Buscar soluções..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-surface-container-low border border-outline-variant/20 rounded-lg pl-10 pr-10 py-2 text-sm w-64 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface transition-colors"
            >
              <X size={14} />
            </button>
          )}
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleTheme}
            className="p-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg transition-all active:scale-95"
            title={theme === 'dark' ? 'Mudar para modo claro' : 'Mudar para modo escuro'}
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button className="p-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg transition-all active:scale-95">
            <Bell size={20} />
          </button>
          <button className="bg-gradient-to-br from-primary to-primary-dim text-on-primary-container px-4 py-2 rounded-lg font-semibold text-sm active:scale-95 transition-all shadow-lg shadow-primary/10 flex items-center gap-2">
            <Plus size={18} />
            Nova solução
          </button>
          <div className="w-10 h-10 rounded-full overflow-hidden border border-outline-variant/20 ml-2">
            <img 
              src="https://picsum.photos/seed/user123/100/100" 
              alt="User Profile" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </div>
    </div>
  </nav>
);

const KPICard = ({ label, value, colorClass, showPulse }: { label: string, value: string, colorClass?: string, showPulse?: boolean }) => (
  <div className="bg-surface-container p-4 rounded-xl border border-outline-variant/10 shadow-sm">
    <p className={`font-label text-[10px] uppercase tracking-wider mb-1 ${colorClass || 'text-on-surface-variant'}`}>{label}</p>
    <div className="flex items-center gap-2">
      <p className="text-3xl font-bold text-on-surface">{value}</p>
      {showPulse && <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span>}
    </div>
  </div>
);

const SolutionCard = ({ solution, onLearnMore }: { solution: Solution, onLearnMore: (s: Solution) => void, key?: string }) => {
  const statusColors = {
    'Em uso': 'bg-secondary/10 text-secondary',
    'Piloto': 'bg-tertiary/10 text-tertiary',
    'Em desenvolvimento': 'bg-primary/10 text-primary'
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.01 }}
      className="group bg-surface-container-low p-6 rounded-2xl transition-all duration-300 hover:bg-surface-container-high glow-card flex flex-col"
    >
      <div className="flex justify-between items-start mb-6">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-xl ${solution.iconBg} flex items-center justify-center ${solution.iconColor}`}>
            {solution.icon}
          </div>
          <div>
            <span className={`font-label text-[10px] uppercase tracking-widest font-bold ${solution.iconColor}`}>
              {solution.category}
            </span>
            <h3 className="text-xl font-bold text-on-surface">{solution.title}</h3>
          </div>
        </div>
        <span className={`px-3 py-1 rounded-full text-[10px] font-bold font-label uppercase tracking-wider ${statusColors[solution.status]}`}>
          {solution.status}
        </span>
      </div>
      
      <div className="space-y-4 mb-8 flex-grow">
        <div className="flex items-center gap-2">
          <User size={14} className="text-on-surface-variant" />
          <span className="text-xs text-on-surface-variant">
            Responsável: <span className="text-on-surface">{solution.responsible}</span>
          </span>
        </div>
        <div className="bg-background/40 p-4 rounded-xl">
          <p className="text-[10px] font-label uppercase text-on-surface-variant tracking-wider mb-2">Impacto Principal</p>
          <p className="text-sm text-on-surface leading-snug">{solution.impact}</p>
        </div>
      </div>
      
      <div className="flex items-center gap-3">
        <button 
          onClick={() => onLearnMore(solution)}
          className="flex-grow bg-primary text-on-primary font-semibold py-2.5 rounded-xl text-sm transition-all hover:opacity-90 active:scale-95 shadow-lg shadow-primary/20 flex items-center justify-center gap-2"
        >
          <Info size={16} />
          Saiba mais
        </button>
        
        {solution.status === 'Em uso' ? (
          <button className="flex-grow bg-surface-container-highest text-on-surface font-semibold py-2.5 rounded-xl text-sm transition-all hover:bg-outline-variant/30 active:scale-95 flex items-center justify-center gap-2">
            <ExternalLink size={14} />
            Acessar
          </button>
        ) : solution.hasDemo ? (
          <button className="flex-grow border border-outline-variant/20 text-on-surface-variant text-sm font-semibold py-2.5 rounded-xl hover:border-primary/40 hover:text-on-surface transition-all flex items-center justify-center gap-2">
            <Share2 size={14} />
            Demo
          </button>
        ) : null}
      </div>
    </motion.div>
  );
};

const SolutionListRow = ({ solution, onLearnMore }: { solution: Solution, onLearnMore: (s: Solution) => void, key?: string }) => {
  const statusColors = {
    'Em uso': 'bg-secondary/10 text-secondary',
    'Piloto': 'bg-tertiary/10 text-tertiary',
    'Em desenvolvimento': 'bg-primary/10 text-primary'
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex items-center gap-6 bg-surface-container-low p-4 rounded-xl hover:bg-surface-container-high transition-all group border border-transparent hover:border-outline-variant/10"
    >
      <div className={`w-10 h-10 rounded-lg ${solution.iconBg} flex items-center justify-center ${solution.iconColor} shrink-0`}>
        {React.cloneElement(solution.icon as React.ReactElement, { size: 20 })}
      </div>
      
      <div className="flex-grow min-w-0">
        <h3 className="font-bold text-on-surface truncate">{solution.title}</h3>
        <p className="text-xs text-on-surface-variant truncate">{solution.category}</p>
      </div>

      <div className="hidden md:block w-48">
        <div className="flex items-center gap-2">
          <User size={12} className="text-on-surface-variant" />
          <span className="text-xs text-on-surface-variant truncate">
            {solution.responsible}
          </span>
        </div>
      </div>

      <div className="shrink-0">
        <span className={`px-3 py-1 rounded-full text-[10px] font-bold font-label uppercase tracking-wider ${statusColors[solution.status]}`}>
          {solution.status}
        </span>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button 
          onClick={() => onLearnMore(solution)}
          className="bg-primary text-on-primary px-4 py-1.5 rounded-lg text-xs font-semibold hover:opacity-90 transition-all shadow-md shadow-primary/10"
        >
          Saiba mais
        </button>
        {solution.status === 'Em uso' ? (
          <button className="bg-surface-container-highest text-on-surface px-4 py-1.5 rounded-lg text-xs font-semibold hover:bg-outline-variant/30 transition-all">
            Acessar
          </button>
        ) : solution.hasDemo ? (
          <button className="border border-outline-variant/20 text-on-surface-variant px-4 py-1.5 rounded-lg text-xs font-semibold hover:text-on-surface hover:border-primary/40 transition-all">
            Demo
          </button>
        ) : null}
      </div>
    </motion.div>
  );
};

const SolutionModal = ({ solution, onClose }: { solution: Solution, onClose: () => void }) => {
  const statusColors = {
    'Em uso': 'bg-secondary/10 text-secondary',
    'Piloto': 'bg-tertiary/10 text-tertiary',
    'Em desenvolvimento': 'bg-primary/10 text-primary'
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative w-full max-w-4xl bg-surface-container rounded-3xl overflow-hidden shadow-2xl border border-outline-variant/10 flex flex-col md:flex-row max-h-[90vh]"
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/20 hover:bg-black/40 text-white rounded-full transition-all"
        >
          <X size={20} />
        </button>

        <div className="w-full md:w-2/5 h-48 md:h-auto relative">
          <img 
            src={solution.imageUrl} 
            alt={solution.title} 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-6">
            <div className={`w-12 h-12 rounded-xl ${solution.iconBg} flex items-center justify-center ${solution.iconColor} mb-3 backdrop-blur-md`}>
              {React.cloneElement(solution.icon as React.ReactElement, { size: 28 })}
            </div>
            <h2 className="text-3xl font-bold text-white">{solution.title}</h2>
            <p className="text-white/80 text-sm">{solution.category}</p>
          </div>
        </div>

        <div className="flex-grow p-6 md:p-10 overflow-y-auto custom-scrollbar">
          <div className="flex items-center justify-between mb-8">
            <span className={`px-4 py-1.5 rounded-full text-xs font-bold font-label uppercase tracking-widest ${statusColors[solution.status]}`}>
              {solution.status}
            </span>
            <div className="flex items-center gap-2 text-on-surface-variant">
              <User size={16} />
              <span className="text-sm font-medium">Responsável: {solution.responsible}</span>
            </div>
          </div>

          <div className="space-y-8">
            <section>
              <h4 className="text-xs font-bold uppercase tracking-widest text-primary mb-3 flex items-center gap-2">
                <Info size={14} /> Sobre a Solução
              </h4>
              <p className="text-on-surface leading-relaxed">
                {solution.description}
              </p>
            </section>

            <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-surface-container-low p-5 rounded-2xl border border-outline-variant/5">
                <h4 className="text-xs font-bold uppercase tracking-widest text-secondary mb-4 flex items-center gap-2">
                  <Target size={14} /> Impacto Gerado
                </h4>
                <p className="text-sm text-on-surface leading-relaxed italic">
                  "{solution.impact}"
                </p>
              </div>

              <div className="bg-surface-container-low p-5 rounded-2xl border border-outline-variant/5">
                <h4 className="text-xs font-bold uppercase tracking-widest text-tertiary mb-4 flex items-center gap-2">
                  <Zap size={14} /> Funcionalidades
                </h4>
                <ul className="space-y-2">
                  {solution.features.map((feature, i) => (
                    <li key={i} className="text-sm text-on-surface flex items-start gap-2">
                      <CheckCircle2 size={14} className="text-tertiary mt-0.5 shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </section>

            <div className="flex items-center gap-4 pt-4">
              <button 
                onClick={onClose}
                className="flex-grow bg-primary text-on-primary font-bold py-4 rounded-2xl transition-all hover:opacity-90 active:scale-[0.98] shadow-xl shadow-primary/20"
              >
                Fechar
              </button>
              {solution.status === 'Em uso' ? (
                <button className="px-8 py-4 rounded-2xl bg-surface-container-highest text-on-surface font-bold hover:bg-outline-variant/30 transition-all flex items-center gap-2">
                  <ExternalLink size={18} />
                  Acessar
                </button>
              ) : solution.hasDemo ? (
                <button className="px-8 py-4 rounded-2xl border border-outline-variant/20 text-on-surface font-bold hover:bg-surface-container-high transition-all flex items-center gap-2">
                  <Share2 size={18} />
                  Demo
                </button>
              ) : null}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const AdminDashboard = ({ 
  solutions, 
  onEdit, 
  onDelete 
}: { 
  solutions: Solution[], 
  onEdit: (s: Solution) => void, 
  onDelete: (id: string) => void 
}) => {
  const stats = [
    { label: 'Total de Soluções', value: solutions.length, icon: <Network size={20} />, color: 'text-primary' },
    { label: 'Em Produção', value: solutions.filter(s => s.status === 'Em uso').length, icon: <CheckCircle2 size={20} />, color: 'text-secondary' },
    { label: 'Em Piloto', value: solutions.filter(s => s.status === 'Piloto').length, icon: <Zap size={20} />, color: 'text-tertiary' },
    { label: 'Aguardando', value: solutions.filter(s => s.status === 'Em desenvolvimento').length, icon: <Clock size={20} />, color: 'text-on-surface-variant' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-surface-container p-6 rounded-2xl border border-outline-variant/10 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-2 rounded-lg bg-surface-container-high ${stat.color}`}>
                {stat.icon}
              </div>
              <span className="text-2xl font-bold text-on-surface">{stat.value}</span>
            </div>
            <p className="text-sm text-on-surface-variant font-medium">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-surface-container rounded-2xl border border-outline-variant/10 overflow-hidden">
        <div className="p-6 border-b border-outline-variant/10 flex justify-between items-center bg-surface-container-low">
          <h3 className="font-bold text-on-surface">Gerenciar Portfólio</h3>
          <button className="bg-primary text-on-primary px-4 py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition-all flex items-center gap-2">
            <Plus size={18} />
            Adicionar Nova
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-surface-container-high">
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-on-surface-variant">Solução</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-on-surface-variant">Status</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-on-surface-variant">Responsável</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-widest text-on-surface-variant text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-outline-variant/10">
              {solutions.map((s) => (
                <tr key={s.id} className="hover:bg-surface-container-low transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg ${s.iconBg} ${s.iconColor} flex items-center justify-center shrink-0`}>
                        {React.cloneElement(s.icon as React.ReactElement, { size: 16 })}
                      </div>
                      <span className="font-semibold text-on-surface">{s.title}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      s.status === 'Em uso' ? 'bg-secondary/10 text-secondary' :
                      s.status === 'Piloto' ? 'bg-tertiary/10 text-tertiary' :
                      'bg-primary/10 text-primary'
                    }`}>
                      {s.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-on-surface-variant">{s.responsible}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => onEdit(s)}
                        className="p-2 text-on-surface-variant hover:text-primary transition-colors"
                        title="Editar"
                      >
                        <Pencil size={16} />
                      </button>
                      <button 
                        onClick={() => onDelete(s.id)}
                        className="p-2 text-on-surface-variant hover:text-error transition-colors"
                        title="Excluir"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const SolutionsCatalog = ({ solutions }: { solutions: Solution[] }) => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-on-surface mb-2">Catálogo Completo</h2>
          <p className="text-on-surface-variant">Explore todas as iniciativas e ferramentas disponíveis em nossa plataforma.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {solutions.map((s) => (
          <div key={s.id} className="bg-surface-container p-6 rounded-2xl border border-outline-variant/10 hover:border-primary/30 transition-all group">
            <div className="flex flex-col lg:flex-row lg:items-center gap-6">
              <div className={`w-16 h-16 rounded-2xl ${s.iconBg} ${s.iconColor} flex items-center justify-center shrink-0 shadow-inner`}>
                {React.cloneElement(s.icon as React.ReactElement, { size: 32 })}
              </div>
              <div className="flex-grow">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-bold text-on-surface">{s.title}</h3>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    s.status === 'Em uso' ? 'bg-secondary/10 text-secondary' :
                    s.status === 'Piloto' ? 'bg-tertiary/10 text-tertiary' :
                    'bg-primary/10 text-primary'
                  }`}>
                    {s.status}
                  </span>
                </div>
                <p className="text-on-surface-variant text-sm leading-relaxed mb-4 max-w-3xl">
                  {s.description}
                </p>
                <div className="flex flex-wrap gap-4">
                  <div className="flex items-center gap-2 text-xs text-on-surface-variant bg-surface-container-high px-3 py-1.5 rounded-lg">
                    <User size={14} />
                    <span>Responsável: <span className="text-on-surface font-medium">{s.responsible}</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-on-surface-variant bg-surface-container-high px-3 py-1.5 rounded-lg">
                    <Network size={14} />
                    <span>Categoria: <span className="text-on-surface font-medium">{s.category}</span></span>
                  </div>
                </div>
              </div>
              <div className="flex lg:flex-col gap-2 shrink-0">
                <button className="flex-grow lg:w-32 bg-primary text-on-primary font-bold py-2.5 rounded-xl text-xs hover:opacity-90 transition-all">
                  Ver Detalhes
                </button>
                {s.status === 'Em uso' && (
                  <button className="flex-grow lg:w-32 bg-surface-container-highest text-on-surface font-bold py-2.5 rounded-xl text-xs hover:bg-outline-variant/30 transition-all">
                    Acessar
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function App() {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('theme');
    return (saved as Theme) || 'dark';
  });
  
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [solutions, setSolutions] = useState<Solution[]>(SOLUTIONS);
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [activeFilter, setActiveFilter] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('Todas');
  const [responsibleFilter, setResponsibleFilter] = useState<string>('Todos');
  const [selectedSolution, setSelectedSolution] = useState<Solution | null>(null);

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  const categories = ['Todas', ...new Set(solutions.map(s => s.category))];
  const responsibles = ['Todos', ...new Set(solutions.map(s => s.responsible))];

  const filteredSolutions = solutions.filter(s => {
    const matchesStatus = activeFilter === 'Todos' || s.status === activeFilter;
    const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         s.impact.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'Todas' || s.category === categoryFilter;
    const matchesResponsible = responsibleFilter === 'Todos' || s.responsible === responsibleFilter;
    
    return matchesStatus && matchesSearch && matchesCategory && matchesResponsible;
  });

  const handleDeleteSolution = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir esta solução?')) {
      setSolutions(prev => prev.filter(s => s.id !== id));
    }
  };

  const handleEditSolution = (solution: Solution) => {
    setSelectedSolution(solution);
    // Em um app real, abriria um formulário de edição.
    // Por enquanto, reutilizamos o modal de detalhes.
  };

  return (
    <div className="min-h-screen flex flex-col">
      <TopNavBar 
        theme={theme} 
        toggleTheme={toggleTheme} 
        searchQuery={searchQuery} 
        setSearchQuery={setSearchQuery} 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
      
      <main className="mt-24 px-8 max-w-[1600px] mx-auto w-full flex-grow">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {/* Hero Section */}
              <section className="mb-12">
                <div className="flex flex-col lg:flex-row justify-between items-end gap-8 mb-12">
                  <div className="max-w-2xl">
                    <motion.h1 
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="text-5xl font-bold tracking-tight mb-4 text-on-surface"
                    >
                      Portfólio de Soluções Digitais
                    </motion.h1>
                    <motion.p 
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 }}
                      className="text-on-surface-variant text-lg leading-relaxed"
                    >
                      Soluções para problemas do dia a dia, automatizações e ferramentas que simplificam o trabalho operacional através da inteligência e tecnologia.
                    </motion.p>
                  </div>
                  
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.2 }}
                    className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full lg:w-auto"
                  >
                    <KPICard label="Total Iniciativas" value="13" />
                    <KPICard label="Em uso" value="05" colorClass="text-secondary" showPulse />
                    <KPICard label="Desenvolvimento" value="08" colorClass="text-primary" />
                    <KPICard label="Piloto" value="02" colorClass="text-tertiary" />
                  </motion.div>
                </div>
              </section>

              <div className="flex flex-col xl:flex-row gap-8">
                {/* Main Content Area */}
                <div className="flex-grow space-y-8">
                  {/* Filter Bar */}
                  <div className="flex flex-wrap items-center gap-4 bg-surface-container/50 p-2 rounded-2xl">
                    <div className="flex items-center p-1 bg-surface-container-low rounded-xl">
                      {[
                        { id: 'Todos', label: 'Todos' },
                        { id: 'Em uso', label: 'Em uso' },
                        { id: 'Em desenvolvimento', label: 'Em desenvolvimento' },
                        { id: 'Piloto', label: 'Piloto' }
                      ].map((filter) => (
                        <button 
                          key={filter.id}
                          onClick={() => setActiveFilter(filter.id)}
                          className={`px-4 py-2 rounded-lg text-sm transition-all whitespace-nowrap ${
                            activeFilter === filter.id 
                              ? 'font-semibold bg-primary text-on-primary-container shadow-lg' 
                              : 'text-on-surface-variant hover:text-on-surface'
                          }`}
                        >
                          {filter.label}
                        </button>
                      ))}
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <div className="relative group min-w-[140px]">
                        <select 
                          value={categoryFilter}
                          onChange={(e) => setCategoryFilter(e.target.value)}
                          className="w-full appearance-none bg-surface-container-high border border-outline-variant/20 rounded-lg px-4 py-2 pr-10 text-sm text-on-surface focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer"
                        >
                          {categories.map(cat => (
                            <option key={cat} value={cat}>{cat === 'Todas' ? 'Todas Categorias' : cat}</option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant" size={16} />
                      </div>
                      
                      <div className="relative group min-w-[140px]">
                        <select 
                          value={responsibleFilter}
                          onChange={(e) => setResponsibleFilter(e.target.value)}
                          className="w-full appearance-none bg-surface-container-high border border-outline-variant/20 rounded-lg px-4 py-2 pr-10 text-sm text-on-surface focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer"
                        >
                          {responsibles.map(resp => (
                            <option key={resp} value={resp}>{resp === 'Todos' ? 'Todos Responsáveis' : resp}</option>
                          ))}
                        </select>
                        <User className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant" size={16} />
                      </div>
                    </div>

                    <div className="flex items-center gap-3 ml-auto">
                      <div className="h-8 w-px bg-outline-variant/20 mx-1"></div>
                      
                      <div className="flex items-center bg-surface-container-high rounded-lg p-1">
                        <button 
                          onClick={() => setViewMode('grid')}
                          className={`p-1.5 rounded-md transition-all ${viewMode === 'grid' ? 'bg-surface-container-highest text-primary' : 'text-on-surface-variant hover:text-on-surface'}`}
                        >
                          <Grid size={20} />
                        </button>
                        <button 
                          onClick={() => setViewMode('list')}
                          className={`p-1.5 rounded-md transition-all ${viewMode === 'list' ? 'bg-surface-container-highest text-primary' : 'text-on-surface-variant hover:text-on-surface'}`}
                        >
                          <ListIcon size={20} />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Solutions Content */}
                  <AnimatePresence mode="wait">
                    {viewMode === 'grid' ? (
                      <motion.div 
                        key="grid"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="grid grid-cols-1 md:grid-cols-2 gap-6"
                      >
                        {filteredSolutions.map((solution) => (
                            <SolutionCard 
                              key={solution.id} 
                              solution={solution} 
                              onLearnMore={setSelectedSolution}
                            />
                          ))}
                      </motion.div>
                    ) : (
                      <motion.div 
                        key="list"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="flex flex-col gap-3"
                      >
                        {filteredSolutions.map((solution) => (
                            <SolutionListRow 
                              key={solution.id} 
                              solution={solution} 
                              onLearnMore={setSelectedSolution}
                            />
                          ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Insights Sidebar */}
                <aside className="w-full xl:w-80 space-y-6">
                  <div className="bg-surface-container p-6 rounded-2xl border border-outline-variant/10">
                    <div className="flex items-center justify-between mb-6">
                      <h4 className="font-bold text-on-surface">Destaques</h4>
                      <Zap className="text-primary fill-primary" size={20} />
                    </div>
                    
                    <div className="space-y-5">
                      {[
                        { label: 'Mais Utilizada', sub: 'Brieflab IA', icon: <TrendingUp size={18} />, color: 'text-primary', bg: 'hover:bg-primary/20' },
                        { label: 'Maior ROI', sub: 'Automação Contratual', icon: <Zap size={18} />, color: 'text-secondary', bg: 'hover:bg-secondary/20' },
                        { label: 'Recém Adicionada', sub: 'Genius Support', icon: <Plus size={18} />, color: 'text-tertiary', bg: 'hover:bg-tertiary/20' }
                      ].map((item, idx) => (
                        <div key={idx} className="flex items-center gap-3 group cursor-pointer">
                          <div className={`w-10 h-10 rounded-lg bg-surface-container-high flex items-center justify-center ${item.color} ${item.bg} transition-all`}>
                            {item.icon}
                          </div>
                          <div>
                            <p className={`text-sm font-semibold text-on-surface group-hover:${item.color} transition-colors`}>{item.label}</p>
                            <p className="text-xs text-on-surface-variant">{item.sub}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-primary/10 to-transparent p-6 rounded-2xl border border-primary/20">
                    <h4 className="text-sm font-bold text-primary mb-2">Sugestão da Semana</h4>
                    <p className="text-xs text-on-surface-variant leading-relaxed mb-4">
                      Que tal automatizar o preenchimento de planilhas de faturamento com nossa nova API?
                    </p>
                    <button className="text-xs font-bold text-on-surface flex items-center gap-2 hover:gap-3 transition-all group">
                      Saiba mais <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>

                  <div className="bg-surface-container rounded-2xl p-6 border border-outline-variant/10 flex flex-col items-center text-center group">
                    <div className="w-32 h-32 mb-4 relative">
                      <div className="absolute inset-0 bg-primary/10 rounded-full blur-2xl group-hover:bg-primary/20 transition-all duration-500"></div>
                      <img 
                        src="https://storage.googleapis.com/static-assets-public/ais-dev-cv75eshe2z6nt636vso7qh-49830042899.us-east5.run.app/attachments/87865f3a-9764-460d-850d-b4f3b6197170.png" 
                        alt="Mascote do Time" 
                        className="w-full h-full object-contain relative z-10 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <p className="text-[10px] font-label uppercase text-primary font-bold tracking-widest mb-1">Mascote Oficial</p>
                    <h4 className="text-xl font-bold text-on-surface">Quack</h4>
                  </div>
                </aside>
              </div>
            </motion.div>
          )}

          {activeTab === 'solutions' && (
            <motion.div
              key="solutions"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <SolutionsCatalog solutions={solutions} />
            </motion.div>
          )}

          {activeTab === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <AdminDashboard 
                solutions={solutions} 
                onEdit={handleEditSolution}
                onDelete={handleDeleteSolution}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="w-full py-12 mt-20 border-t border-outline-variant/10 bg-background">
        <div className="flex flex-col md:flex-row justify-between items-center px-12 max-w-[1600px] mx-auto gap-8">
          <div className="flex flex-col items-center md:items-start gap-2">
            <span className="text-on-surface font-semibold">Portfólio de Soluções Digitais</span>
            <span className="font-label text-xs uppercase tracking-widest text-on-surface-variant">© 2026. INTERAÇÕES DIGITAIS.</span>
          </div>
          
          <div className="flex gap-8">
            <a href="#" className="font-label text-xs uppercase tracking-widest text-on-surface-variant hover:text-primary transition-colors">Suporte</a>
            <a href="#" className="font-label text-xs uppercase tracking-widest text-on-surface-variant hover:text-primary transition-colors">Documentação</a>
            <a href="#" className="font-label text-xs uppercase tracking-widest text-on-surface-variant hover:text-primary transition-colors">Privacidade</a>
          </div>
        </div>
      </footer>

      <AnimatePresence>
        {selectedSolution && (
          <SolutionModal 
            solution={selectedSolution} 
            onClose={() => setSelectedSolution(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
